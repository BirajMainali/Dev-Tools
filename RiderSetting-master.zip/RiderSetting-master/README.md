# RiderSetting
settings for rider ide
